
Please select an issue template from
https://github.com/facebookresearch/detectron2/issues/new/choose .

Otherwise your issue will be closed.
